package Eg::C;

1;

