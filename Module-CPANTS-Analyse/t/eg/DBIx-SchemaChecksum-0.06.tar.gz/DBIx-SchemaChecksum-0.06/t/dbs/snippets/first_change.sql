-- preSHA1sum: 89049e457886a86886a4fdf1f905b69250a8236c
-- postSHA1sum: d9a02517255045167053ea92dace728e1389f8ca

create table yat (
	yet_another_column text
);

