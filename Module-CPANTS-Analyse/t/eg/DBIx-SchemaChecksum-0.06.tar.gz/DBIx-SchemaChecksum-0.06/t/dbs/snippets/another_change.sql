-- preSHA1sum: d9a02517255045167053ea92dace728e1389f8ca
-- postSHA1sum: 7a1263a17bc9648e06de64fabb688633feb04f05

alter table yat add column foo text;

