use Acme::DonMartin;

print "hello, world\n";
