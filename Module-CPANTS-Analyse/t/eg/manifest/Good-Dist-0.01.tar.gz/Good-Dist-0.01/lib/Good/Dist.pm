
package Good::Dist;

use strict;
use warnings;

our $VERSION = '0.01';

1;

__END__

=head1 NAME

Good::Dist - a perfect distribution wrt CPANTS

=head1 SYNOPSIS

    use Good::Dist; # compiles and does nothing

=head1 DESCRIPTION

This is just a show-off.

