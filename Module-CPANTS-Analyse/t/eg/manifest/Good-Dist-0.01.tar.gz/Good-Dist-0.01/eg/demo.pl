
use Good::Dist;

print "bye\n";
# pretty impressive, ain't it?
