
package bad::manifest;

use strict;
use warnings;

our $VERSION = '0.01';

1;

__END__

=head1 NAME

bad::manifest - a test distribution for CPANTS (bad manifest)

=head1 SYNOPSIS

    use bad::manifest; # compiles and does nothing

=head1 DESCRIPTION

This is just a show-off.

