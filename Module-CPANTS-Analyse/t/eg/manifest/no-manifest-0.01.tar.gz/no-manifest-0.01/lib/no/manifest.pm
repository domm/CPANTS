
package no::manifest;

use strict;
use warnings;

our $VERSION = '0.01';

1;

__END__

=head1 NAME

no::manifest - a test distribution for CPANTS (no manifest)

=head1 SYNOPSIS

    use no::manifest; # compiles and does nothing

=head1 DESCRIPTION

This is just a show-off.

